/* eslint-disable */
/** nesto.ca
 * UTMZ Cookie Replicator
 * @ref https://www.bounteous.com/insights/2017/12/18/utmz-cookie-replicator-gtm/
 *
 * Makes a generally faithful representation of the old __utmz cookie
 * from Classic Analytics. Stores the data in a cookie named __utmzz.
 * Also sets a session cookie named __utmzzses.
 *
 * Data is stored in the __utmzz cookie in the following format; brackets
 * indicate optional data and are aexcluded from the stored string:
 *
 * utmcsr=SOURCE|utmcmd=MEDIUM[|utmccn=CAMPAIGN][|utmcct=CONTENT]
 * [|utmctr=TERM/KEYWORD]
 *
 * e.g.:
 *
 * utmcsr=example.com|utmcmd=affl-link|utmccn=foo|utmcct=bar|utmctr=biz
 *
 * Follows the same campaign assignment/overriding flow as Classic Analytics.
 */
(function(document) {
    var referrer = document.referrer;
    var gaReferral = {
        utmcsr: '(direct)',
        utmcmd: '(none)',
        utmccn: '(not set)',
        channel: 'Direct'
    };
    var thisHostname = document.location.hostname;
    var thisDomain = getDomain_(thisHostname);
    var referringDomain = getDomain_(document.referrer);
    var sessionCookie = getCookie_('__utmzzses');
    var cookieExpiration = new Date(+new Date() + 1000 * 60 * 60 * 24 * 30 * 6);
    var qs = document.location.search.replace('?', '');
    var hash = document.location.hash.replace('#', '');
    var gaParams = parseGoogleParams(qs + '#' + hash);
    var partnerParam = parsePartnerParam(qs);
    var referringInfo = parseGaReferrer(referrer);
    var storedVals = getCookie_('__utmz') || getCookie_('__utmzz');
    var newCookieVals = [];
    var keyMap = {
        utm_source: 'utmcsr',
        utm_medium: 'utmcmd',
        utm_campaign: 'utmccn',
        utm_content: 'utmcct',
        utm_term: 'utmctr',
        gclid: 'utmgclid',
        dclid: 'utmdclid',
        wbraid: 'utmwbraid',
        msclkid: 'msclkid'
    };
    var keyName, values, _val, _key, raw, key, len, i;

    if (sessionCookie && referringDomain === thisDomain) {
        gaParams = null;
        referringInfo = null;

        //GREG, 20190221 - create cookie to indicate it's an existing session
        //writeCookie_('__existingsess', 1, null, '/', thisDomain);
    } //GREG - 20190221 - create cookie with session creation time
    else {
        var cookieCreationDate = new Date();
        writeCookie_(
            '__existingsess',
            cookieCreationDate,
            null,
            '/',
            thisDomain
        );
    }

    if (
        gaParams &&
        (gaParams.utm_source ||
            gaParams.gclid ||
            gaParams.dclid ||
            gaParams.wbraid ||
            gaParams.msclkid)
    ) {
        for (key in gaParams) {
            if (typeof gaParams[key] !== 'undefined') {
                keyName = keyMap[key];
                gaReferral[keyName] = gaParams[key];
            }
        }

        if (gaParams.gclid || gaParams.dclid) {
            gaReferral.utmcsr = 'google';
            gaReferral.utmcmd = gaReferral.utmgclid ? 'cpc' : 'cpm';
        } else if (gaParams.wbraid) {
            gaReferral.utmcsr = 'google';
            gaReferral.utmcmd = 'cpc';
        } else if (gaParams.msclkid) {
            gaReferral.utmcsr = 'bing';
            gaReferral.utmcmd = 'cpc';
        }
    } else if (referringInfo) {
        gaReferral.utmcsr = referringInfo.source;
        gaReferral.utmcmd = referringInfo.medium;
        if (referringInfo.term) gaReferral.utmctr = referringInfo.term;
    } else if (storedVals) {
        values = {};
        raw = storedVals.split('|');
        len = raw.length;

        for (i = 0; i < len; i++) {
            _val = raw[i].split('=');
            _key = _val[0].split('.').pop();
            values[_key] = _val[1];
        }

        gaReferral = values;
    }

    //GREG 20230714: set channel value based on info - copied from cm.ca script
    if (gaReferral.utmcsr === 'vip') {
        // utm_source = “vip” => 'VIP'
        gaReferral.channel = 'VIP';
    } else if (gaReferral.utmcsr === 'taboola') {
        // utm_source contains “taboola” => 'Paid referral'
        gaReferral.channel = 'Paid referral';
    } else if (partnerParam) {
        // partner parameter present => Partners
        gaReferral.channel = 'Partners';
    } else if (
        gaReferral.utmcsr === '(direct)' &&
        gaReferral.utmccn === '(not set)'
    ) {
        // no referrer or utm parameters => Direct
        gaReferral.channel = 'Direct';
    } else if (gaReferral.utmcmd === 'organic') {
        // “medium” is defined as “organic” => Organic Search
        gaReferral.channel = 'Organic Search';
    } else if (matchSocial(gaReferral)) {
        // utm_source contains one of [facebook, instagram, twitter, linkedin, pinterest]
        //    OR referrer contains one of [facebook, instagram, twitter, linkedin, pinterest, reddit, yelp, livejournal]
        //    OR utm_medium matches regex `^(social|social-network|social-media|sm|social network|social media)$`
        //    => Social
        gaReferral.channel = 'Social';
    } else if (gaReferral.utmcmd === 'email') {
        // utm_medium = email => Email
        gaReferral.channel = 'Email';
    } else if (
        gaReferral.utmcsr === 'fintel' ||
        gaReferral.utmcmd === 'affiliate' ||
        gaReferral.utmcmd === 'affiliates'
    ) {
        // source = 'fintel' OR medium = 'affiliate' or 'affiliates' => Affiliates
        gaReferral.channel = 'Affiliates';
    } else if (gaReferral.utmcmd.match(/^(cpc|ppc|paidsearch)$/)) {
        // utm_medium matches regex ^(cpc|ppc|paidsearch)$ => Paid Search
        gaReferral.channel = 'Paid Search';
    } else if (gaReferral.utmcmd.match(/^(cpv|cpa|cpp|content-text)$/)) {
        // utm_medium matches regex ^(cpv|cpa|cpp|content-text)$ => Other Advertising
        gaReferral.channel = 'Other Advertising';
    } else if (gaReferral.utmcmd.match(/^(display|cpm|banner)$/)) {
        // utm_medium matches regex ^(display|cpm|banner)$ => Display
        gaReferral.channel = 'Display';
    } else if (gaReferral.utmcmd === 'referral') {
        // utm_medium = referral => Referral
        gaReferral.channel = 'Referral';
    } else {
        gaReferral.channel = 'Other';
    }

    for (key in gaReferral) {
        if (typeof gaReferral[key] !== 'undefined') {
            newCookieVals.push(key + '=' + gaReferral[key]);
        }
    }

    writeCookie_(
        '__utmzz',
        newCookieVals.join('|'),
        cookieExpiration,
        '/',
        thisDomain
    );
    writeCookie_('__utmzzses', 1, null, '/', thisDomain);

    // Write session nesto_partner if `partner` param is defined in the URL
    if (partnerParam) {
        writeCookie_('nesto_partner', partnerParam, null, '/', thisDomain);
    }

    function parseGoogleParams(str) {
        var campaignParams = [
            'source',
            'medium',
            'campaign',
            'term',
            'content'
        ];
        var regex = new RegExp(
            '(utm_(' +
                campaignParams.join('|') +
                ')|(d|g)clid|(wbraid)|(msclkid))=.*?([^&#]*|$)',
            'gi'
        );
        var gaParams = str.match(regex);
        var paramsObj, vals, len, i;

        if (gaParams) {
            paramsObj = {};
            len = gaParams.length;

            for (i = 0; i < len; i++) {
                vals = gaParams[i].split('=');

                if (vals) {
                    paramsObj[vals[0]] = vals[1];
                }
            }
        }

        return paramsObj;
    }

    /** GREG 20230714 - copied from cm.ca script
     * Parse social source from details
     */
    function matchSocial(currentParams) {
        var socials = [
            'facebook',
            'instagram',
            'twitter',
            'linkedin',
            'pinterest',
            'reddit',
            'yelp',
            'livejournal'
        ];

        var isReferrerSocial = socials.includes(currentParams.utmcsr);
        var isMediumSocial = currentParams.utmcmd.match(
            /^(social|social-network|social-media|sm|social network|social media)$/
        );

        return isReferrerSocial || Boolean(isMediumSocial);
    }

    /**
     * Parse Partner Param from query strings
     * @param {String} qs query string document.location.search without `?`
     * @returns {null | String} return qs value or `null` if not defined in the URL
     */
    function parsePartnerParam(qs) {
        var regex = new RegExp('(partner)=.*?([^&#]*|$)', 'gi');
        var partnerParam = qs.match(regex);
        var partner = null;

        if (partnerParam && partnerParam.length >= 1) {
            keyVal = partnerParam[0].split('=');
            partner = keyVal[1];
        }

        return partner;
    }

    function parseGaReferrer(referrer) {
        if (!referrer) return;

        var searchEngines = {
            'daum.net': {
                p: 'q',
                n: 'daum'
            },
            'eniro.se': {
                p: 'search_word',
                n: 'eniro '
            },
            'naver.com': {
                p: 'query',
                n: 'naver '
            },
            'yahoo.com': {
                p: 'p',
                n: 'yahoo'
            },
            'msn.com': {
                p: 'q',
                n: 'msn'
            },
            'bing.com': {
                p: 'q',
                n: 'bing'
            },
            'aol.com': {
                p: 'q',
                n: 'aol'
            },
            'lycos.com': {
                p: 'q',
                n: 'lycos'
            },
            'ask.com': {
                p: 'q',
                n: 'ask'
            },
            'altavista.com': {
                p: 'q',
                n: 'altavista'
            },
            'search.netscape.com': {
                p: 'query',
                n: 'netscape'
            },
            'cnn.com': {
                p: 'query',
                n: 'cnn'
            },
            'about.com': {
                p: 'terms',
                n: 'about'
            },
            'mamma.com': {
                p: 'query',
                n: 'mama'
            },
            'alltheweb.com': {
                p: 'q',
                n: 'alltheweb'
            },
            'voila.fr': {
                p: 'rdata',
                n: 'voila'
            },
            'search.virgilio.it': {
                p: 'qs',
                n: 'virgilio'
            },
            'baidu.com': {
                p: 'wd',
                n: 'baidu'
            },
            'alice.com': {
                p: 'qs',
                n: 'alice'
            },
            'yandex.com': {
                p: 'text',
                n: 'yandex'
            },
            'najdi.org.mk': {
                p: 'q',
                n: 'najdi'
            },
            'seznam.cz': {
                p: 'q',
                n: 'seznam'
            },
            'search.com': {
                p: 'q',
                n: 'search'
            },
            'wp.pl': {
                p: 'szukaj ',
                n: 'wirtulana polska'
            },
            'online.onetcenter.org': {
                p: 'qt',
                n: 'o*net'
            },
            'szukacz.pl': {
                p: 'q',
                n: 'szukacz'
            },
            'yam.com': {
                p: 'k',
                n: 'yam'
            },
            'pchome.com': {
                p: 'q',
                n: 'pchome'
            },
            'kvasir.no': {
                p: 'q',
                n: 'kvasir'
            },
            'sesam.no': {
                p: 'q',
                n: 'sesam'
            },
            'ozu.es': {
                p: 'q',
                n: 'ozu '
            },
            'terra.com': {
                p: 'query',
                n: 'terra'
            },
            'mynet.com': {
                p: 'q',
                n: 'mynet'
            },
            'ekolay.net': {
                p: 'q',
                n: 'ekolay'
            },
            'rambler.ru': {
                p: 'words',
                n: 'rambler'
            },
            google: {
                p: 'q',
                n: 'google'
            },
            'duckduckgo.com': {
                p: 'q',
                n: 'duckduckgo'
            }
        };
        var a = document.createElement('a');
        var values = {};
        var searchEngine, termRegex, term;

        a.href = referrer;

        // Shim for the billion google search engines
        if (a.hostname.indexOf('google') > -1) {
            referringDomain = 'google';
        }

        if (searchEngines[referringDomain]) {
            searchEngine = searchEngines[referringDomain];
            termRegex = new RegExp(searchEngine.p + '=.*?([^&#]*|$)', 'gi');
            term = a.search.match(termRegex);

            values.source = searchEngine.n;
            values.medium = 'organic';

            values.term =
                (term ? term[0].split('=')[1] : '') || '(not provided)';
        } else if (referringDomain !== thisDomain) {
            values.source = a.hostname;
            values.medium = 'referral';
        }

        return values;
    }

    function writeCookie_(name, value, expiration, path, domain) {
        var str = name + '=' + value + ';';
        if (expiration) str += 'Expires=' + expiration.toGMTString() + ';';
        if (path) str += 'Path=' + path + ';';
        if (domain) str += 'Domain=' + domain + ';';

        document.cookie = str;
    }

    function getCookie_(name) {
        var cookies = '; ' + document.cookie;
        var cvals = cookies.split('; ' + name + '=');

        if (cvals.length > 1) return cvals.pop().split(';')[0];
    }

    function getDomain_(url) {
        if (!url) return;

        var a = document.createElement('a');
        a.href = url;

        try {
            return a.hostname.match(/[^.]*\.[^.]{2,3}(?:\.[^.]{2,3})?$/)[0];
        } catch (squelch) {}
    }
})(document);
